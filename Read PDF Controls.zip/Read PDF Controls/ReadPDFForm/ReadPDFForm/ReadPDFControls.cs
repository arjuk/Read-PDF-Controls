﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Activities;
using System.ComponentModel;
using iTextSharp.text.pdf;
using System.Data;
using System.IO;


namespace ReadPDFForm
{
    public class ReadPDFControls : CodeActivity<DataTable>
    {
        int txtCount = 0;
        int btnCount = 0;
        int chkBoxCount = 0;
        int rdButtonCount = 0;
        int dropDownCount = 0;
        
        
        string cName, cType, cValue;

        DataTable filedDetails;
        DataRow dr;

        [Category("Input")]
        [RequiredArgument]
        public InArgument<string> PDFFileName { get; set; }

        [Category("Output")]
        public OutArgument<DataTable> FieldsWithValue { get; set; }

        private static string GetFormFieldNamesWithValues(PdfReader pdfReader)
        {
             return string.Join("\r\n", pdfReader.AcroFields.Fields
            .Select(x => x.Key + "=" +
                     pdfReader.AcroFields.GetField(x.Key)+"="+pdfReader.AcroFields.GetFieldType(x.Key)).ToArray());
           
        }
        protected override DataTable Execute(CodeActivityContext context)
        {     
            var fileName = PDFFileName.Get(context);
            var fields = GetFormFieldNamesWithValues(new PdfReader(fileName));
            string[] splitRows = fields.Split(new[] { Environment.NewLine },StringSplitOptions.None);
            filedDetails = new DataTable("PDF Table");
            filedDetails.Columns.AddRange(new[] { new DataColumn("Control Name"), new DataColumn("Control Type"), new DataColumn("Control Value") });
            
            foreach (string row in splitRows)
            {

                dr = filedDetails.NewRow();
                string [] str = row.Split("=".ToCharArray(),StringSplitOptions.None);

                cName = str[0].ToString();
                cValue = str[1].ToString();
                if (str[2].ToString()=="1")
                {
                    btnCount++;
                    cType = "Button" +btnCount.ToString();
                }
                else if (str[2].ToString() == "2")
                {
                    chkBoxCount++;
                    cType = "Check Box" + chkBoxCount.ToString();

                }
                else if (str[2].ToString() == "3")
                {
                    rdButtonCount++;
                    cType = "Radio Button"+rdButtonCount.ToString();
                }
                else if (str[2].ToString() == "4")
                {
                     txtCount++;
                    cType = "Text Field"+txtCount.ToString();
                }
                else if (str[2].ToString() == "6")
                {
                    dropDownCount++;
                    cType = "Drop Down"+dropDownCount.ToString();
                }                
                  dr[0] = cName;
                  dr[1] = cType;
                  dr[2] = cValue;
                
                filedDetails.Rows.Add(dr);           
                
            }
            FieldsWithValue.Set(context, filedDetails);
            return filedDetails;
        }
    }
}
