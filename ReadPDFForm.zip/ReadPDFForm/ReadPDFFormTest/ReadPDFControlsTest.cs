﻿using System;
using System.Activities;
using System.Diagnostics;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Data;
using ReadPDFForm;



namespace ReadPDFFormTest
{
    [TestClass]
    public class ReadPDFControlsTest
    {
        [TestMethod]
        public void TestMethod1()
        {

            //var data = new DataTable();
            //data.Columns.AddRange(new[] { new DataColumn("UID") });
            //data.Rows.Add(@"C:\UiPathTest\OoPdfFormExample.pdf");

            var param = new System.Collections.Generic.Dictionary<string, object>
            {
                { "PDFFileName", @"C:\UiPathTest\OoPdfFormExample.pdf" }
                
            };
            var results = WorkflowInvoker.Invoke(new ReadPDFControls(), param);
            var res = results.ToString();
            Debug.Print(results.ToString());
           /* foreach (DataRow dt in results.Rows)
            {
                Debug.Print(dt[1].ToString());
            }*/
        }
    }
}
